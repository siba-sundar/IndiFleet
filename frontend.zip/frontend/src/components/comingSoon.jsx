import Img from "../assets/coming-soon.png"

function ComingSoon () {
    return (
       <>
       <img src={Img} alt="" className="h-full w-full" />
       <button></button>
       </> 
    )
}



export default ComingSoon